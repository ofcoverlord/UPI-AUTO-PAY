<?php
return [
    
    'bot_token' => '7452323366:AAGt70kY7ra3mXg5W68YOvqYeeSTZm0lLV4',
    
    'channels' => ['@true12g_offical', '@true12g_offical', '@true12g_offical'], // Add your channels here
    
    'channels_on_check' => ['@true12g_offical','@true12g_offical'], // Add your channels to check here
    
    'bonus_amount' => 2, // Set your bonus amount here
    
    'per_reffer_bonus' => 3, // Set your per referral bonus here
    
    'min_withdraw_limit' => 10, // Set your minimum withdrawal limit here
    
    'f2s_payout_mid' => 'YOUR_F2S_PAYOUT_MID', // Full2sms payout mid
    
    'f2s_payout_mkey' => 'YOUR_F2S_PAYOUT_MKEY', // Full2sms payout mkey
    
    'f2s_payout_guid' => 'YOUR_F2S_PAYOUT_GUID' // Full2sms payout guid
];